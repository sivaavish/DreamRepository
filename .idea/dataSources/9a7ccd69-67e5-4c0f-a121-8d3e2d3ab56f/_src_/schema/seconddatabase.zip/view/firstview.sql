CREATE VIEW firstview AS
  SELECT
    `seconddatabase`.`customers`.`cid`       AS `cid`,
    `seconddatabase`.`customers`.`firstName` AS `firstName`,
    `seconddatabase`.`customers`.`lastName`  AS `lastName`,
    `seconddatabase`.`customers`.`email`     AS `email`,
    `seconddatabase`.`customers`.`phone`     AS `phone`
  FROM `seconddatabase`.`customers`;
